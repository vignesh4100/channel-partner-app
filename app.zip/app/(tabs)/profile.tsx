import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  TextInput,
  Alert,
  RefreshControl, // 👈 Import RefreshControl
} from "react-native";
import { auth, firestore, logoutUser } from "../../firebaseConfig";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import profile from "@/assets/images/profile.png";
import { router } from "expo-router";

export default function ProfileScreen() {
  const [user, setUser] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false); // 👈 Add refreshing state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
  });

  const fetchProfileData = async (currentUser: any) => {
    if (!currentUser) return;

    try {
      setFormData((prev) => ({ ...prev, email: currentUser.email || "" }));

      const userDoc = await getDoc(doc(firestore, "channel_partners", currentUser.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        setFormData({
          name: userData?.full_name || "",
          email: currentUser.email || "",
          phone: userData?.phone_no || "",
          company: userData?.company_name || "",
        });
      }
    } catch (error) {
      console.error("Failed to fetch profile data:", error);
    }
  };

  // Fetch user and profile data on mount
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        await fetchProfileData(currentUser);
      } else {
        setUser(null);
      }
    });

    return () => unsubscribe();
  }, []);


  const onRefresh = useCallback(async () => {
    if (user) {
      setRefreshing(true);
      await fetchProfileData(user);
      setRefreshing(false);
    }
  }, [user]);

  const handleUpdate = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      await setDoc(doc(firestore, "channel_partners", user.uid), formData, { merge: true });
      Alert.alert("Success", "Profile updated successfully!");
      setIsEditing(false);
    } catch (error) {
      console.error("Failed to update profile:", error);
      Alert.alert("Error", "Failed to update profile.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      Alert.alert("Success", "Logged out successfully.");
      router.replace('/(auth)/login')
    } catch (error) {
      console.error("Failed to logout:", error);
      Alert.alert("Error", "Failed to logout.");
    }
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>Please log in to view your profile.</Text>
      </View>
    );
  }

  return (
    <ScrollView 
    style={styles.container}
    refreshControl={
      <RefreshControl refreshing={refreshing} onRefresh={onRefresh} style={{marginTop:50}}/>
    }
    
    >
      <View style={styles.header}>
        <Image
          source={profile}
          style={styles.avatar}
        />
        <Text style={styles.name}>{formData.name || "User"}</Text>
        <Text style={styles.company}>{formData.company || "No Company"}</Text>
      </View>

      <View style={styles.content}>
        {isEditing ? (
          <View style={styles.form}>
            {/** Full Name */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Full Name</Text>
              <TextInput
                style={styles.input}
                value={formData.name}
                onChangeText={(text) => setFormData({ ...formData, name: text })}
              />
            </View>

            {/** Email (Non-editable) */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                value={formData.email}
                editable={false}
                keyboardType="email-address"
              />
            </View>

            {/** Phone Number */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Phone</Text>
              <TextInput
                style={styles.input}
                value={formData.phone}
                onChangeText={(text) => setFormData({ ...formData, phone: text })}
                keyboardType="phone-pad"
              />
            </View>

            {/** Company */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Company</Text>
              <TextInput
                style={styles.input}
                value={formData.company}
                onChangeText={(text) => setFormData({ ...formData, company: text })}
              />
            </View>

            {/** Save Changes Button */}
            <TouchableOpacity style={styles.button} onPress={handleUpdate}>
              <Text style={styles.buttonText}>{isLoading ? "Updating..." : "Save Changes"}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.info}>
            {/** Display Profile Information */}
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Email</Text>
              <Text style={styles.infoValue}>{formData.email}</Text>
            </View>

            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Phone</Text>
              <Text style={styles.infoValue}>{formData.phone || "N/A"}</Text>
            </View>

            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Company</Text>
              <Text style={styles.infoValue}>{formData.company || "N/A"}</Text>
            </View>
          </View>
        )}

        {/** Action Buttons */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, !isEditing && styles.editButton]}
            onPress={() => setIsEditing(!isEditing)}
          >
            <Text style={styles.buttonText}>{isEditing ? "Cancel" : "Edit Profile"}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleLogout}>
            <Text style={styles.buttonText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f8f8",
  },
  header: {
    backgroundColor: "#fff",
    padding: 20,
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
    marginTop: 40,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 50,
    marginBottom: 10,
    // borderColor: "black",
    // borderWidth: 1
  },
  name: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1a1a1a",
  },
  company: {
    fontSize: 16,
    color: "#666",
    marginTop: 5,
  },
  content: {
    padding: 20,
  },
  info: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  infoItem: {
    marginBottom: 10,
  },
  infoLabel: {
    fontSize: 14,
    color: "#666",
    marginBottom: 3,
  },
  infoValue: {
    fontSize: 16,
    color: "#1a1a1a",
  },
  form: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    color: "#666",
    marginBottom: 5,
  },
  input: {
    backgroundColor: "#f5f5f5",
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
  },
  actions: {
    gap: 10,
  },
  button: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  editButton: {
    backgroundColor: "#27375d",
  },
  logoutButton: {
    backgroundColor: "#FF3B30",
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  message: {
    marginTop: 50,
    textAlign: "center",
    fontSize: 18,
    color: "#666",
  },
});
