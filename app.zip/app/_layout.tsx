import { useEffect, useState } from 'react';
import { Slot, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, firestore } from '../firebaseConfig';
import { doc, getDoc } from 'firebase/firestore';

export default function Layout() {
  const [authChecked, setAuthChecked] = useState(false);
  const [needsPasswordReset, setNeedsPasswordReset] = useState(false);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userDoc = await getDoc(doc(firestore, 'channel_partners', user.uid));
        const hasTempPassword = userDoc.exists() && userDoc.data().temp_password_hash;
        setNeedsPasswordReset(hasTempPassword);
        
        // Force immediate check if we're on reset screen but shouldn't be
        if (!hasTempPassword) {
          router.replace('/(tabs)');
        }
      }
      setAuthChecked(true);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!authChecked) return;

    const inAuthGroup = segments[0] === '(auth)';
    
    if (!auth.currentUser) {
      if (!inAuthGroup) router.replace('/(auth)/login');
    } else {
      if (needsPasswordReset) {
        if (segments[0] !== 'ResetPasswordScreen') {
          router.replace('/ResetPasswordScreen');
        }
      } else if (inAuthGroup) {
        router.replace('/(tabs)');
      }
    }
  }, [authChecked, segments, needsPasswordReset]);

  return (
    <>
      <Slot />
      <StatusBar style="dark" />
    </>
  );
}