import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Alert,
    Linking,
    ScrollView,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { auth } from '../firebaseConfig';


export default function AgreementUploadScreen() {
    const [file, setFile] = useState(null);
    const router = useRouter();
    const [agreementExists, setAgreementExists] = useState(false);
    const userId = auth.currentUser?.uid;

    const pickDocument = async () => {
        const result = await DocumentPicker.getDocumentAsync({
            type: 'application/pdf',
        });

        if (!result.canceled) {
            setFile(result.assets[0]);
        }
    };

    useEffect(() => {
        const checkAgreement = async () => {
            try {
                const response = await fetch(`https://noqu.co.in/agreements/CP-Agreements/${userId}.pdf`, {
                    method: 'HEAD',
                });
                if (response.ok) {
                    setAgreementExists(true);
                } else {
                    setAgreementExists(false);
                }
            } catch (error) {
                console.log('Agreement check failed:', error);
                setAgreementExists(false);
            }
        };

        if (userId) checkAgreement();
    }, []);


    const handleUpload = () => {
        if (!file) {
            Alert.alert('No File', 'Please select a file first.');
            return;
        }

        // Simulate upload
        Alert.alert(
            'Uploaded',
            `Simulated upload: Your agreement "${file.name}" would be saved as https://noqu.co.in/agreements/CP-Agreements/${userId}.pdf`
        );

        setFile(null);
    };

    const handleDownloadSample = () => {
        const fileUrl = 'https://noqu.co.in/agreements/CP-Agreement.pdf';
        Linking.openURL(fileUrl).catch(() =>
            Alert.alert('Error', 'Unable to open sample agreement.')
        );
    };

    const handleViewAgreement = () => {
        const fileUrl = `https://noqu.co.in/agreements/CP-Agreements/${userId}.pdf`;
        Linking.openURL(fileUrl).catch(() =>
            Alert.alert('Error', 'No agreement found or file URL is broken.')
        );
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            {/* 🔙 Nav */}
            <View style={styles.Nav}>
                <View style={styles.navContent}>
                    <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                        <Ionicons name="chevron-back" size={24} color="#27375d" />
                    </TouchableOpacity>
                    <Text style={styles.title}>Upload Agreement</Text>
                </View>
            </View>

            {/* 📝 Card */}
            <View style={styles.card}>
                <TouchableOpacity style={styles.buttonOutline} onPress={handleDownloadSample}>
                    <Text style={styles.buttonOutlineText}>📥 Download Sample Agreement</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.button} onPress={pickDocument}>
                    <Text style={styles.buttonText}>Select PDF File</Text>
                </TouchableOpacity>

                {file && (
                    <View style={styles.preview}>
                        <Text style={styles.previewText}>Selected File:</Text>
                        <Text style={styles.fileName}>{file.name}</Text>
                    </View>
                )}

                <TouchableOpacity style={[styles.button, styles.uploadButton]} onPress={handleUpload}>
                    <Text style={styles.buttonText}>Upload</Text>
                </TouchableOpacity>

                {agreementExists && (
                    <TouchableOpacity
                        style={[styles.button, styles.viewButton]}
                        onPress={handleViewAgreement}
                    >
                        <Text style={styles.buttonText}>View My Agreement</Text>
                    </TouchableOpacity>
                )}
            </View>

            {/* 💡 Instructions */}
            <View style={styles.infoCard}>
                <Text style={styles.infoTitle}>📌 Instructions:</Text>
                <Text style={styles.infoText}>• Upload the signed agreement in PDF format.</Text>
                <Text style={styles.infoText}>• Download the sample above to get started.</Text>
                <Text style={styles.infoText}>• Your agreement will be reviewed by admin.</Text>
                <Text style={styles.infoText}>• You’ll be activated after verification.</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#f4f4f4',
        paddingBottom: 40,
    },
    Nav: {
        width: '100%',
        height: 80,
        backgroundColor: '#ffbb08',
        justifyContent: 'center',
        paddingTop: 25,
    },
    navContent: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
    },
    backButton: {
        marginRight: 10,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#27375d',
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 16,
        padding: 20,
        margin: 20,
        elevation: 3,
        borderWidth: 1,
        borderColor: '#ccc',
    },
    button: {
        backgroundColor: '#ffbb08',
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 15,
    },
    uploadButton: {
        backgroundColor: '#27375d',
    },
    viewButton: {
        backgroundColor: '#34C759',
    },
    buttonText: {
        color: '#fff',
        fontWeight: '600',
        fontSize: 16,
    },
    buttonOutline: {
        borderWidth: 1.5,
        borderColor: '#27375d',
        borderRadius: 8,
        paddingVertical: 12,
        alignItems: 'center',
    },
    buttonOutlineText: {
        color: '#27375d',
        fontWeight: '600',
        fontSize: 16,
    },
    preview: {
        marginTop: 15,
        alignItems: 'center',
    },
    previewText: {
        fontSize: 14,
        color: '#555',
    },
    fileName: {
        fontSize: 15,
        fontWeight: '500',
        color: '#000',
        marginTop: 5,
    },
    infoCard: {
        backgroundColor: '#fff',
        borderRadius: 16,
        padding: 20,
        borderWidth: 1,
        borderColor: '#ccc',
        marginHorizontal: 20,
    },
    infoTitle: {
        fontSize: 18,
        fontWeight: '700',
        marginBottom: 10,
        color: '#27375d',
    },
    infoText: {
        fontSize: 15,
        color: '#444',
        marginBottom: 6,
    },
});
