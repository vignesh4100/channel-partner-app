import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, Linking, Alert, TouchableOpacity } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { doc, getDoc } from 'firebase/firestore';
import { firestore } from '../../firebaseConfig';
import Timeline from 'react-native-timeline-flatlist';
import { AntDesign } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function LeadDetailScreen() {
  const { leadId } = useLocalSearchParams(); // Ensure leadId comes from route params
  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter(); // Get router instance

  type Lead = {
    leadID?: string;
    companyName: string;
    contactName: string;
    email: string;
    phone: string;
    userId: string;
    stage: string;
    status: Record<string, any>;
    details: Record<string, any>;
    createdAt: string | Date;
    lastUpdated: string | Date;
    demoScheduledTime?: string | Date;
    lastCallDate?: string | Date;
    followedBy?: string;
    quotationPdfUrl?: string;
    invoicePdfUrl?: string;
  };

  useEffect(() => {
    const fetchLead = async () => {
      if (!leadId) {
        console.error('Lead ID is missing.');
        setLoading(false);
        return;
      }

      try {
        const leadDoc = await getDoc(doc(firestore, 'leads', leadId as string));
        if (leadDoc.exists()) {
          setLead(leadDoc.data() as Lead);
        } else {
          console.warn('Lead not found.');
        }
      } catch (error) {           
        console.error('Error fetching lead:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLead();
  }, [leadId]);

  // Timeline Data for Stages
  const stages = [
    { title: 'Follow-Up', description: lead?.details?.followUp || 'No follow-up details.' },
    { title: 'Demo Scheduled', description: lead?.details?.demo || 'No demo scheduled.' },
    { title: 'Pre-Sales', description: lead?.details?.quotation || 'No quotation available.' },
    { title: 'Sale Completed', description: lead?.details?.invoice || 'No invoice generated.' }
  ];

  if (loading) {
    return <ActivityIndicator size="large" color="#ffbb08" style={styles.loader} />;
  }

  if (!lead) {
    return <Text style={styles.errorText}>No lead details available.</Text>;
  }

  const openLink = (url: string) => {
    if (!url) {
      Alert.alert('Error', 'No URL provided.');
      return;
    }

    const validUrl = url.startsWith('http') ? url : `https://${url}`;

    Linking.canOpenURL(validUrl)
      .then((supported) => {
        if (supported) {
          Linking.openURL(validUrl);
        } else {
          Alert.alert('Error', 'Cannot open link.');
        }
      })
      .catch(() => Alert.alert('Error', 'Failed to open link.'));
  };

  const isFirestoreTimestamp = (value: any): value is { seconds: number; nanoseconds: number } =>
    typeof value === 'object' && value !== null && 'seconds' in value && 'nanoseconds' in value;



  return (
    <>
      <View style={styles.Nav}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backIcon}>
          <AntDesign name="left" size={20} color="#27375d" />
        </TouchableOpacity>
        <Text style={styles.title}>Lead Details</Text>
      </View>
      <ScrollView style={styles.container}>

        {/* Timeline Progress Bar */}
        <Timeline
          data={stages}
          circleSize={20}
          circleColor="#ffbb08"
          lineColor="#27375d"
          innerCircle={'dot'}
          descriptionStyle={styles.timelineDescription}
          options={{ removeClippedSubviews: false }}
        />

        {/* Lead Summary */}
        <View style={styles.leadDetails}>
          <Text style={styles.sectionTitle}>Lead Information</Text>
          <Text style={styles.detailText}>Company Name: {lead?.companyName}</Text>
          <Text style={styles.detailText}>Contact Person: {lead?.contactName}</Text>
          <Text style={styles.detailText}>Email: {lead?.email}</Text>
          <Text style={styles.detailText}>Phone: {lead?.phone}</Text>
          <Text style={styles.detailText}>Status: {lead?.status.stage}</Text>
        </View>

        <View style={styles.stageDetails}>
          <Text style={styles.sectionTitle}>Stage Details</Text>

          {lead?.status?.details
            ? Object.entries(lead.status.details).map(([key, value]) => (
              <View key={key} style={styles.stageCard}>
                <Text style={styles.stageTitle}>
                  {key
                    .replace(/([A-Z])/g, ' $1')        // Add space before uppercase letters
                    .replace(/^./, str => str.toUpperCase())  // Capitalize first character
                    .trim()}:
                </Text>

                {/* Handle Different Data Types */}
                {typeof value === 'string' ? (
                  value.startsWith('http') ? (
                    <Text
                      style={styles.linkText}
                      onPress={() => Linking.openURL(value)}
                    >
                      {value.endsWith('.pdf') ? '📄 View PDF' : '🗂️ View PDF'}
                    </Text>
                  ) : (
                    <Text style={styles.stageText}>{value}</Text>
                  )
                ) : value instanceof Date || (value?.seconds && value?.nanoseconds) ? (
                  <Text style={styles.stageTime}>
                    {new Date(
                      value.seconds ? value.seconds * 1000 : value
                    ).toLocaleString()}
                  </Text>
                ) : (
                  <Text style={styles.stageText}>No valid value available.</Text>
                )}
              </View>
            ))
            : (
              <Text style={styles.stageText}>No stage details available.</Text>
            )}
        </View>



      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  Nav: {
    width: '100%',
    backgroundColor: '#ffbb08',
    padding: 15,
    display: 'flex',
    // justifyContent:'center',
    flexDirection: 'row',
    paddingTop: 40,
    paddingBottom: 15,
    gap: 10,
  },
  backIcon: { marginTop: 3 },
  container: { flex: 1, backgroundColor: '#f8f8f8', padding: 10 },
  title: { fontSize: 20, fontWeight: 'bold', color: '#27375d' },
  loader: { marginTop: 100 },
  errorText: { textAlign: 'center', color: 'red', marginTop: 20 },
  leadDetails: { padding: 10, backgroundColor: '#fff', borderRadius: 10, marginVertical: 10 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: 'black', marginBottom: 10 },
  detailText: { fontSize: 14, color: '#444', marginVertical: 3 },
  stageDetails: { padding: 10, backgroundColor: '#fff', borderRadius: 10, marginVertical: 10 },
  stageCard: { padding: 8, marginBottom: 5, backgroundColor: '#f1f1f1', borderRadius: 8 },
  stageTitle: { fontSize: 14, fontWeight: '600', color: '#27375d' },
  stageText: { fontSize: 14, color: '#555'},
  stageTime: { fontSize: 13, color: '#555', marginTop: 3},
  timelineDescription: { color: '#666' },
  linkText: { color: '#1e90ff', textDecorationLine: 'underline' },
});