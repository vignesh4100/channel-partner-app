// BusinessScreen.jsx - Based on LeadsScreen layout

import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as SecureStore from 'expo-secure-store';
import axiosInstance from '@/utils/axiosInstance';

export default function BusinessScreen() {
  const router = useRouter();
  const [commissions, setCommissions] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [refreshing, setRefreshing] = useState(false);

  const fetchBusinessData = async () => {
    const userId = await SecureStore.getItemAsync('cpId');
    if (!userId) return;
    setRefreshing(true);
    try {
      const response = await axiosInstance.get(`/get-commissions/${userId}`);
      const data = response.data || [];
      setCommissions(data);
      setFiltered(data);
    } catch (error) {
      console.error('Error fetching commission data:', error);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchBusinessData();
  }, []);

  const onRefresh = useCallback(() => {
    fetchBusinessData();
  }, []);

  const handleCategorySelect = (category) => {
    setActiveCategory(category);
    if (category === 'All') {
      setFiltered(commissions);
    } else if (category === 'Renewals') {
      const filteredData = commissions.filter(item => item.status === 'paid');
      setFiltered(filteredData);
    } else {
      const filteredData = commissions.filter(item => item.status === category.toLowerCase());
      setFiltered(filteredData);
    }
  };

  const getTotalRevenue = () => {
    return commissions.reduce((sum, item) => sum + (item.commission_amount || 0), 0);
  };

  const renderItem = ({ item }) => (
    <View style={styles.leadCard}>
      <View style={styles.leadHeader}>
        <Text style={styles.companyName}>{item.lead_name || 'Lead'}</Text>
        <Text style={[styles.status, { color: item.status === 'paid' ? '#34C759' : '#FF9500' }]}> {item.status} </Text>
      </View>
      <Text style={styles.contactName}>Amount: ₹{item.commission_amount}</Text>
      <Text style={styles.email}>Lead Value: ₹{item.sale_amount}</Text>
      <View style={styles.footer}>
        <Text style={styles.date}>
          {item.created_at ? new Date(item.created_at).toLocaleDateString() : 'N/A'}
        </Text>
      </View>
    </View>
  );

  return (
    <>
      <View style={styles.Nav}>
        <View style={styles.navContent}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={24} color="#27375d" />
          </TouchableOpacity>
          <Text style={styles.title}>Business</Text>
        </View>
      </View>

      <View style={styles.cardGrid}>
        {[
          { label: 'Total Revenue', value: `₹${getTotalRevenue()}`, key: 'All' },
          { label: 'Payment complete', value: commissions.filter(c => c.status === 'paid').length, key: 'paid' },
          { label: 'Payment Inprocess', value: commissions.filter(c => c.status === 'pending').length, key: 'pending' },
          { label: 'Renewals', value: commissions.filter(c => c.status === 'paid').length, key: 'Renewals' },
        ].map((card) => (
          <TouchableOpacity
            key={card.key}
            style={[styles.card, activeCategory === card.key && styles.activeCard]}
            onPress={() => handleCategorySelect(card.key)}
          >
            <Text style={styles.cardLabel}>{card.label}</Text>
            <Text style={styles.cardCount}>{card.value}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.container}>
        {refreshing ? (
          <ActivityIndicator size="large" color="#ffbb08" />
        ) : (
          <FlatList
            data={filtered}
            renderItem={renderItem}
            keyExtractor={(item, index) => index.toString()}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={["#ffbb08"]} />}
            contentContainerStyle={styles.listContainer}
            ListEmptyComponent={<Text style={styles.emptyText}>No records found.</Text>}
          />
        )}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  Nav: {
    width: '100%',
    height: 80,
    backgroundColor: '#ffbb08',
    justifyContent: 'center',
    paddingTop: 25,
  },
  navContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#27375d',
    marginLeft: 20,
  },
  cardGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingTop: 15,
    gap: 10,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
    paddingRight: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    elevation: 2,
  },
  activeCard: {
    borderColor: '#27375d',
  },
  cardLabel: {
    fontSize: 13,
    color: '#555',
    fontWeight: '600',
  },
  cardCount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#27375d',
  },
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  listContainer: {
    padding: 15,
  },
  leadCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderLeftWidth: 4,
    borderLeftColor: '#ffbb08',
  },
  leadHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  companyName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#27375d',
  },
  status: {
    fontSize: 14,
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  contactName: {
    fontSize: 16,
    color: '#4a4a4a',
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  date: {
    fontSize: 12,
    color: '#8e8e93',
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#888',
    marginTop: 20,
  },
});