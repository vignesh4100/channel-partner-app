import React from 'react';
import { View, StyleSheet, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import { useLocalSearchParams } from 'expo-router';

export default function PdfViewerScreen() {
  const { url } = useLocalSearchParams();

  const viewerUrl = `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(url)}`;

  if (!url) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#27375d" />
      </View>
    );
  }

  return (
    <WebView
      source={{ uri: viewerUrl }}
      style={styles.container}
      javaScriptEnabled
      startInLoadingState
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});
